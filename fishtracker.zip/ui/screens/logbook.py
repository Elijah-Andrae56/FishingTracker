from kivy.uix.screenmanager import Screen

class LogbookScreen(Screen):
    pass     # will list sessions later
